let closeBtn = document.querySelector('.close');
closeBtn.addEventListener('click', function(){
    window.close();
})